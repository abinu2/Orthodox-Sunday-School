"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Download, FileText, ImageIcon, Music, Video, BookOpen } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { useAuth } from "@/contexts/auth-context"

interface Resource {
  id: string
  title: string
  description: string
  type: "pdf" | "image" | "audio" | "video"
  category: string
  uploadDate: string
  size: string
  downloads: number
  uploadedBy: string
}

export default function LibraryPage() {
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [activeTab, setActiveTab] = useState("all")

  const resources: Resource[] = [
    {
      id: "1",
      title: "The Nativity Fast Guide",
      description: "Complete guide to observing the 40-day fast before Christmas",
      type: "pdf",
      category: "Lesson Plans",
      uploadDate: "2024-12-01",
      size: "2.3 MB",
      downloads: 45,
      uploadedBy: "Fr. John",
    },
    {
      id: "2",
      title: "Orthodox Icons Collection",
      description: "High-resolution images of traditional Orthodox icons",
      type: "image",
      category: "Visual Resources",
      uploadDate: "2024-11-28",
      size: "15.7 MB",
      downloads: 32,
      uploadedBy: "Maria K.",
    },
    {
      id: "3",
      title: "Liturgical Chants Audio",
      description: "Traditional Orthodox chants for Sunday school",
      type: "audio",
      category: "Audio Resources",
      uploadDate: "2024-11-25",
      size: "8.4 MB",
      downloads: 28,
      uploadedBy: "Stefan P.",
    },
    {
      id: "4",
      title: "Divine Liturgy Explanation",
      description: "Educational video explaining the Orthodox Divine Liturgy",
      type: "video",
      category: "Educational Videos",
      uploadDate: "2024-11-20",
      size: "125 MB",
      downloads: 67,
      uploadedBy: "Ana M.",
    },
    {
      id: "5",
      title: "Saints Coloring Pages",
      description: "Printable coloring pages featuring Orthodox saints",
      type: "pdf",
      category: "Worksheets",
      uploadDate: "2024-11-15",
      size: "5.2 MB",
      downloads: 89,
      uploadedBy: "Maria K.",
    },
    {
      id: "6",
      title: "Orthodox Prayers Book",
      description: "Collection of essential Orthodox prayers for children",
      type: "pdf",
      category: "Prayers",
      uploadDate: "2024-11-10",
      size: "3.1 MB",
      downloads: 156,
      uploadedBy: "Fr. John",
    },
  ]

  const categories = [
    "Lesson Plans",
    "Prayers",
    "Chant Guides",
    "Visual Resources",
    "Educational Videos",
    "Worksheets",
    "Audio Resources",
  ]

  const getFileIcon = (type: Resource["type"]) => {
    switch (type) {
      case "pdf":
        return FileText
      case "image":
        return ImageIcon
      case "audio":
        return Music
      case "video":
        return Video
      default:
        return FileText
    }
  }

  const getTypeColor = (type: Resource["type"]) => {
    switch (type) {
      case "pdf":
        return "default"
      case "image":
        return "secondary"
      case "audio":
        return "outline"
      case "video":
        return "destructive"
      default:
        return "default"
    }
  }

  const filteredResources = resources.filter((resource) => {
    const matchesSearch =
      resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resource.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || resource.category === selectedCategory
    const matchesType = selectedType === "all" || resource.type === selectedType
    const matchesTab = activeTab === "all" || resource.type === activeTab

    return matchesSearch && matchesCategory && matchesType && matchesTab
  })

  if (!user) return null

  return (
    <DashboardLayout role={user.role}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Resource Library</h1>
          <p className="text-muted-foreground">Access lesson materials, prayers, chants, and educational content</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Search & Filter Resources</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search resources..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full md:w-[150px]">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="image">Images</SelectItem>
                  <SelectItem value="audio">Audio</SelectItem>
                  <SelectItem value="video">Video</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Resources</TabsTrigger>
            <TabsTrigger value="pdf">Documents</TabsTrigger>
            <TabsTrigger value="image">Images</TabsTrigger>
            <TabsTrigger value="audio">Audio</TabsTrigger>
            <TabsTrigger value="video">Videos</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredResources.map((resource) => {
                const IconComponent = getFileIcon(resource.type)
                return (
                  <Card key={resource.id}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-100 rounded-lg">
                            <IconComponent className="h-6 w-6 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <CardTitle className="text-lg">{resource.title}</CardTitle>
                            <CardDescription className="text-sm">{resource.description}</CardDescription>
                          </div>
                        </div>
                        <Badge variant={getTypeColor(resource.type)}>{resource.type.toUpperCase()}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm text-muted-foreground">
                          <span>Category: {resource.category}</span>
                          <span>Size: {resource.size}</span>
                        </div>

                        <div className="flex justify-between text-sm text-muted-foreground">
                          <span>By: {resource.uploadedBy}</span>
                          <span>{resource.downloads} downloads</span>
                        </div>

                        <div className="text-xs text-muted-foreground">
                          Uploaded: {new Date(resource.uploadDate).toLocaleDateString()}
                        </div>

                        <Button className="w-full">
                          <Download className="mr-2 h-4 w-4" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {filteredResources.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No resources found</h3>
                  <p className="text-muted-foreground">Try adjusting your search or filter criteria</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
