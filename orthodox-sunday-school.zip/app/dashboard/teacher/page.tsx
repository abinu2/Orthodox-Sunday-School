import { TeacherDashboard } from "@/components/dashboards/teacher-dashboard"

export default function TeacherDashboardPage() {
  return <TeacherDashboard />
}
