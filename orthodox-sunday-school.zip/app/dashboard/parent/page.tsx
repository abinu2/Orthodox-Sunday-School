import { ParentDashboard } from "@/components/dashboards/parent-dashboard"

export default function ParentDashboardPage() {
  return <ParentDashboard />
}
