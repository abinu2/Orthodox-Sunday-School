"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Calendar, Award, TrendingUp, Play, FileText } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"

export function StudentDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const stats = [
    { title: "Lessons Completed", value: "12/15", icon: BookOpen, progress: 80 },
    { title: "Attendance Rate", value: "95%", icon: Calendar, progress: 95 },
    { title: "Assessment Score", value: "88%", icon: TrendingUp, progress: 88 },
    { title: "Achievements", value: "3", icon: Award, progress: 100 },
  ]

  const upcomingLessons = [
    {
      id: "1",
      title: "The Nativity Fast",
      date: "Tomorrow, 10:00 AM",
      description: "Understanding the spiritual significance of the 40-day fast",
      status: "upcoming",
    },
    {
      id: "2",
      title: "Saints and Icons",
      date: "Next Sunday, 10:00 AM",
      description: "Learning about Orthodox iconography",
      status: "scheduled",
    },
  ]

  const recentAssessments = [
    {
      id: "1",
      title: "Orthodox Traditions Quiz",
      score: 92,
      date: "2024-12-01",
      status: "completed",
    },
    {
      id: "2",
      title: "Saints Reflection",
      score: 85,
      date: "2024-11-28",
      status: "completed",
    },
    {
      id: "3",
      title: "Liturgy Understanding",
      score: null,
      date: "2024-12-08",
      status: "pending",
    },
  ]

  return (
    <DashboardLayout role="student">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">My Learning Dashboard</h1>
          <p className="text-muted-foreground">Track your progress and continue your Orthodox education journey</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <Progress value={stat.progress} className="mt-2 h-2" />
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="lessons">My Lessons</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Lessons</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {upcomingLessons.map((lesson) => (
                    <div key={lesson.id} className="flex items-start justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-medium">{lesson.title}</h4>
                        <p className="text-sm text-muted-foreground">{lesson.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">{lesson.date}</p>
                      </div>
                      <Badge variant={lesson.status === "upcoming" ? "default" : "outline"}>{lesson.status}</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <p className="font-medium">Completed Orthodox Traditions Quiz</p>
                    <p className="text-muted-foreground">Score: 92% • 2 days ago</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">Attended Saints and Icons lesson</p>
                    <p className="text-muted-foreground">1 week ago</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">Earned "High Achiever" badge</p>
                    <p className="text-muted-foreground">1 week ago</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="lessons" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>My Lessons</CardTitle>
                <CardDescription>Continue your Orthodox education journey</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingLessons.map((lesson) => (
                    <div key={lesson.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <BookOpen className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{lesson.title}</h4>
                          <p className="text-sm text-muted-foreground">{lesson.description}</p>
                          <p className="text-xs text-muted-foreground">{lesson.date}</p>
                        </div>
                      </div>
                      <Button variant="outline">
                        <Play className="mr-2 h-4 w-4" />
                        Start Lesson
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Assessments & Quizzes</CardTitle>
                <CardDescription>Track your learning progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentAssessments.map((assessment) => (
                    <div key={assessment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-green-100 rounded-lg">
                          <FileText className="h-6 w-6 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{assessment.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            Due: {new Date(assessment.date).toLocaleDateString()}
                          </p>
                          {assessment.score && (
                            <p className="text-sm font-medium text-green-600">Score: {assessment.score}%</p>
                          )}
                        </div>
                      </div>
                      <Badge variant={assessment.status === "completed" ? "default" : "outline"}>
                        {assessment.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>My Achievements</CardTitle>
                <CardDescription>Celebrate your learning milestones</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <div className="p-4 border rounded-lg text-center">
                    <Award className="h-12 w-12 text-yellow-500 mx-auto mb-2" />
                    <h4 className="font-medium">High Achiever</h4>
                    <p className="text-sm text-muted-foreground">Scored 90%+ on 3 assessments</p>
                  </div>
                  <div className="p-4 border rounded-lg text-center">
                    <Calendar className="h-12 w-12 text-blue-500 mx-auto mb-2" />
                    <h4 className="font-medium">Perfect Attendance</h4>
                    <p className="text-sm text-muted-foreground">Attended all lessons this month</p>
                  </div>
                  <div className="p-4 border rounded-lg text-center">
                    <BookOpen className="h-12 w-12 text-green-500 mx-auto mb-2" />
                    <h4 className="font-medium">Dedicated Learner</h4>
                    <p className="text-sm text-muted-foreground">Completed 10+ lessons</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
