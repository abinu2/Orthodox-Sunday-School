"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, BookOpen, Upload, CheckSquare } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { AttendanceTracker } from "@/components/features/attendance-tracker"
import { LessonManager } from "@/components/features/lesson-manager"
import { ResourceUpload } from "@/components/features/resource-upload"
import { StudentProgress } from "@/components/features/student-progress"

export function TeacherDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const stats = [
    { title: "Active Students", value: "24", icon: Users, change: "+2 this week" },
    { title: "Lessons This Month", value: "8", icon: BookOpen, change: "2 upcoming" },
    { title: "Avg Attendance", value: "89%", icon: CheckSquare, change: "+5% from last month" },
    { title: "Resources Uploaded", value: "15", icon: Upload, change: "3 this week" },
  ]

  return (
    <DashboardLayout role="teacher">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Teacher Dashboard</h1>
          <p className="text-muted-foreground">Manage your classes and track student progress</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat) => (
            <Card key={stat.title}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">{stat.change}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="lessons">Lessons</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="progress">Student Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Classes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">The Nativity Fast</p>
                      <p className="text-sm text-muted-foreground">Sunday, 10:00 AM</p>
                    </div>
                    <Badge>Tomorrow</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Saints and Icons</p>
                      <p className="text-sm text-muted-foreground">Sunday, 11:15 AM</p>
                    </div>
                    <Badge variant="outline">This Week</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <p className="font-medium">Maria submitted reflection</p>
                    <p className="text-muted-foreground">2 hours ago</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">New resource uploaded</p>
                    <p className="text-muted-foreground">Yesterday</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">Class attendance recorded</p>
                    <p className="text-muted-foreground">2 days ago</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="lessons">
            <LessonManager />
          </TabsContent>

          <TabsContent value="attendance">
            <AttendanceTracker />
          </TabsContent>

          <TabsContent value="resources">
            <ResourceUpload />
          </TabsContent>

          <TabsContent value="progress">
            <StudentProgress />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
