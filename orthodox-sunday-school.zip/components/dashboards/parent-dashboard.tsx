"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { BookOpen, Calendar, MessageCircle, Bell, Award } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"

export function ParentDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  const children = [
    {
      id: "1",
      name: "Maria Popovic",
      class: "Intermediate",
      attendance: 95,
      progress: 80,
      lastLesson: "Saints and Icons",
      nextLesson: "The Nativity Fast",
      achievements: ["Perfect Attendance", "High Achiever"],
    },
    {
      id: "2",
      name: "Stefan Popovic",
      class: "Beginners",
      attendance: 88,
      progress: 75,
      lastLesson: "Orthodox Prayers",
      nextLesson: "Church Calendar",
      achievements: ["Dedicated Learner"],
    },
  ]

  const upcomingEvents = [
    {
      id: "1",
      title: "Christmas Pageant Practice",
      date: "2024-12-10",
      time: "2:00 PM",
      type: "Service Project",
    },
    {
      id: "2",
      title: "Parent-Teacher Conference",
      date: "2024-12-12",
      time: "6:00 PM",
      type: "Meeting",
    },
    {
      id: "3",
      title: "St. Nicholas Celebration",
      date: "2024-12-19",
      time: "10:00 AM",
      type: "Feast Day",
    },
  ]

  const notifications = [
    {
      id: "1",
      message: "Maria completed her Saints reflection assignment",
      time: "2 hours ago",
      type: "achievement",
    },
    {
      id: "2",
      message: "Stefan missed last Sunday's class",
      time: "3 days ago",
      type: "attendance",
    },
    {
      id: "3",
      message: "New resource uploaded: Nativity Fast Guide",
      time: "1 week ago",
      type: "resource",
    },
  ]

  return (
    <DashboardLayout role="parent">
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Parent Portal</h1>
          <p className="text-muted-foreground">Stay connected with your children's Orthodox education journey</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="calendar">Calendar</TabsTrigger>
            <TabsTrigger value="communication">Messages</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              {children.map((child) => (
                <Card key={child.id}>
                  <CardHeader>
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src="/placeholder.svg?height=48&width=48" alt={child.name} />
                        <AvatarFallback>
                          {child.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle className="text-lg">{child.name}</CardTitle>
                        <CardDescription>{child.class} Class</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">Attendance</p>
                        <div className="flex items-center space-x-2">
                          <Progress value={child.attendance} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{child.attendance}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm font-medium">Progress</p>
                        <div className="flex items-center space-x-2">
                          <Progress value={child.progress} className="flex-1 h-2" />
                          <span className="text-sm font-medium">{child.progress}%</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Last Lesson:</span>
                        <span className="font-medium">{child.lastLesson}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Next Lesson:</span>
                        <span className="font-medium">{child.nextLesson}</span>
                      </div>
                    </div>

                    {child.achievements.length > 0 && (
                      <div>
                        <p className="text-sm font-medium mb-2">Recent Achievements</p>
                        <div className="flex flex-wrap gap-1">
                          {child.achievements.map((achievement, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              <Award className="mr-1 h-3 w-3" />
                              {achievement}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Events</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {upcomingEvents.slice(0, 3).map((event) => (
                    <div key={event.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{event.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(event.date).toLocaleDateString()} at {event.time}
                        </p>
                      </div>
                      <Badge variant="outline">{event.type}</Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Notifications</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {notifications.slice(0, 3).map((notification) => (
                    <div key={notification.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                      <Bell className="h-4 w-4 text-muted-foreground mt-0.5" />
                      <div className="flex-1">
                        <p className="text-sm">{notification.message}</p>
                        <p className="text-xs text-muted-foreground">{notification.time}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-4">
            <div className="space-y-6">
              {children.map((child) => (
                <Card key={child.id}>
                  <CardHeader>
                    <CardTitle>{child.name} - Detailed Progress</CardTitle>
                    <CardDescription>{child.class} Class Performance</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="text-center p-4 border rounded-lg">
                        <Calendar className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                        <div className="text-2xl font-bold">{child.attendance}%</div>
                        <p className="text-sm text-muted-foreground">Attendance Rate</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <BookOpen className="h-8 w-8 text-green-500 mx-auto mb-2" />
                        <div className="text-2xl font-bold">{child.progress}%</div>
                        <p className="text-sm text-muted-foreground">Lesson Progress</p>
                      </div>
                      <div className="text-center p-4 border rounded-lg">
                        <Award className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
                        <div className="text-2xl font-bold">{child.achievements.length}</div>
                        <p className="text-sm text-muted-foreground">Achievements</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="calendar" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Upcoming Events & Schedule</CardTitle>
                <CardDescription>Stay informed about important dates and activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingEvents.map((event) => (
                    <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="p-2 bg-blue-100 rounded-lg">
                          <Calendar className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{event.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {new Date(event.date).toLocaleDateString()} at {event.time}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">{event.type}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="communication" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Messages & Communication</CardTitle>
                <CardDescription>Connect with teachers and stay updated</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Button className="w-full">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Send Message to Teacher
                  </Button>

                  <div className="space-y-3">
                    {notifications.map((notification) => (
                      <div key={notification.id} className="flex items-start space-x-3 p-4 border rounded-lg">
                        <Bell className="h-5 w-5 text-muted-foreground mt-0.5" />
                        <div className="flex-1">
                          <p className="text-sm">{notification.message}</p>
                          <p className="text-xs text-muted-foreground mt-1">{notification.time}</p>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {notification.type}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
