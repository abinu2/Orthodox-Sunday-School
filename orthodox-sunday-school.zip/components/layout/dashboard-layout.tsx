"use client"

import type React from "react"

import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Home, BookOpen, Users, Calendar, FileText, Settings, LogOut, BarChart3, Upload } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface DashboardLayoutProps {
  children: React.ReactNode
  role: "teacher" | "student" | "parent" | "admin"
}

export function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const { user, logout } = useAuth()
  const router = useRouter()

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  const getNavItems = () => {
    const baseItems = [
      { href: `/dashboard/${role}`, label: "Dashboard", icon: Home },
      { href: "/calendar", label: "Calendar", icon: Calendar },
      { href: "/library", label: "Resources", icon: FileText },
    ]

    switch (role) {
      case "teacher":
        return [
          ...baseItems,
          { href: "/dashboard/teacher/lessons", label: "Lessons", icon: BookOpen },
          { href: "/dashboard/teacher/students", label: "Students", icon: Users },
          { href: "/dashboard/teacher/upload", label: "Upload", icon: Upload },
        ]
      case "student":
        return [
          ...baseItems,
          { href: "/dashboard/student/lessons", label: "My Lessons", icon: BookOpen },
          { href: "/dashboard/student/progress", label: "Progress", icon: BarChart3 },
        ]
      case "admin":
        return [
          ...baseItems,
          { href: "/dashboard/admin/analytics", label: "Analytics", icon: BarChart3 },
          { href: "/dashboard/admin/users", label: "Users", icon: Users },
          { href: "/dashboard/admin/settings", label: "Settings", icon: Settings },
        ]
      default:
        return baseItems
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link href={`/dashboard/${role}`} className="text-xl font-bold text-blue-600">
                Orthodox Sunday School
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden md:flex space-x-4">
                {getNavItems().map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center space-x-1 px-3 py-2 text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 rounded-md"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Link>
                ))}
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src="/placeholder.svg?height=32&width=32" alt={user?.name} />
                      <AvatarFallback>{user?.name?.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user?.name}</p>
                      <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">{children}</main>
    </div>
  )
}
