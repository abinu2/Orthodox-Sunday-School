"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { TrendingUp, TrendingDown, Award, BookOpen } from "lucide-react"

interface StudentProgress {
  id: string
  name: string
  avatar: string
  attendance: number
  assessmentScore: number
  lessonsCompleted: number
  totalLessons: number
  trend: "up" | "down" | "stable"
  achievements: string[]
}

export function StudentProgress() {
  const students: StudentProgress[] = [
    {
      id: "1",
      name: "Maria Popovic",
      avatar: "/placeholder.svg?height=40&width=40",
      attendance: 95,
      assessmentScore: 88,
      lessonsCompleted: 12,
      totalLessons: 15,
      trend: "up",
      achievements: ["Perfect Attendance", "Top Performer"],
    },
    {
      id: "2",
      name: "Stefan Milic",
      avatar: "/placeholder.svg?height=40&width=40",
      attendance: 87,
      assessmentScore: 92,
      lessonsCompleted: 11,
      totalLessons: 15,
      trend: "up",
      achievements: ["High Achiever"],
    },
    {
      id: "3",
      name: "Ana Jovanovic",
      avatar: "/placeholder.svg?height=40&width=40",
      attendance: 78,
      assessmentScore: 75,
      lessonsCompleted: 9,
      totalLessons: 15,
      trend: "down",
      achievements: [],
    },
    {
      id: "4",
      name: "Nikola Petrovic",
      avatar: "/placeholder.svg?height=40&width=40",
      attendance: 92,
      assessmentScore: 85,
      lessonsCompleted: 13,
      totalLessons: 15,
      trend: "stable",
      achievements: ["Consistent Learner"],
    },
  ]

  const getTrendIcon = (trend: StudentProgress["trend"]) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-500" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-500" />
      default:
        return null
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-blue-600"
    if (score >= 70) return "text-yellow-600"
    return "text-red-600"
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Student Progress</h2>
        <p className="text-muted-foreground">Track individual student performance and engagement</p>
      </div>

      <div className="grid gap-4">
        {students.map((student) => (
          <Card key={student.id}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={student.avatar || "/placeholder.svg"} alt={student.name} />
                    <AvatarFallback>
                      {student.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>

                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold">{student.name}</h3>
                      {getTrendIcon(student.trend)}
                    </div>
                    <div className="flex items-center space-x-4 mt-2">
                      <div className="flex items-center space-x-1">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          {student.lessonsCompleted}/{student.totalLessons} lessons
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className={`text-2xl font-bold ${getScoreColor(student.assessmentScore)}`}>
                    {student.assessmentScore}%
                  </div>
                  <p className="text-sm text-muted-foreground">Assessment Score</p>
                </div>
              </div>

              <div className="mt-6 space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Attendance Rate</span>
                    <span>{student.attendance}%</span>
                  </div>
                  <Progress value={student.attendance} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Lesson Progress</span>
                    <span>{Math.round((student.lessonsCompleted / student.totalLessons) * 100)}%</span>
                  </div>
                  <Progress value={(student.lessonsCompleted / student.totalLessons) * 100} className="h-2" />
                </div>

                {student.achievements.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <Award className="h-4 w-4 text-yellow-500" />
                    <div className="flex flex-wrap gap-1">
                      {student.achievements.map((achievement, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {achievement}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
