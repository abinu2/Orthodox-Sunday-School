"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Save } from "lucide-react"
import { format } from "date-fns"

interface Student {
  id: string
  name: string
  present: boolean
}

export function AttendanceTracker() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [students, setStudents] = useState<Student[]>([
    { id: "1", name: "Maria Popovic", present: true },
    { id: "2", name: "Stefan Milic", present: true },
    { id: "3", name: "Ana Jovanovic", present: false },
    { id: "4", name: "Nikola Petrovic", present: true },
    { id: "5", name: "Milica Stojanovic", present: true },
    { id: "6", name: "Marko Nikolic", present: false },
  ])

  const toggleAttendance = (studentId: string) => {
    setStudents((prev) =>
      prev.map((student) => (student.id === studentId ? { ...student, present: !student.present } : student)),
    )
  }

  const presentCount = students.filter((s) => s.present).length
  const attendanceRate = Math.round((presentCount / students.length) * 100)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Attendance Tracking</CardTitle>
          <CardDescription>Record student attendance for your classes</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-[240px] justify-start text-left font-normal bg-transparent">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>

              <div className="flex items-center space-x-2">
                <Badge variant="secondary">
                  {presentCount}/{students.length} Present
                </Badge>
                <Badge variant={attendanceRate >= 80 ? "default" : "destructive"}>{attendanceRate}% Rate</Badge>
              </div>
            </div>

            <Button>
              <Save className="mr-2 h-4 w-4" />
              Save Attendance
            </Button>
          </div>

          <div className="space-y-3">
            {students.map((student) => (
              <div key={student.id} className="flex items-center space-x-3 p-3 border rounded-lg">
                <Checkbox
                  id={student.id}
                  checked={student.present}
                  onCheckedChange={() => toggleAttendance(student.id)}
                />
                <label
                  htmlFor={student.id}
                  className="flex-1 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {student.name}
                </label>
                <Badge variant={student.present ? "default" : "secondary"}>
                  {student.present ? "Present" : "Absent"}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
