"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, BookOpen, Calendar, Users } from "lucide-react"

interface Lesson {
  id: string
  title: string
  description: string
  date: string
  duration: string
  students: number
  status: "upcoming" | "completed" | "draft"
}

export function LessonManager() {
  const [lessons, setLessons] = useState<Lesson[]>([
    {
      id: "1",
      title: "The Nativity Fast",
      description: "Understanding the spiritual significance of the 40-day fast before Christmas",
      date: "2024-12-08",
      duration: "45 min",
      students: 24,
      status: "upcoming",
    },
    {
      id: "2",
      title: "Saints and Icons",
      description: "Learning about Orthodox iconography and veneration of saints",
      date: "2024-12-01",
      duration: "50 min",
      students: 22,
      status: "completed",
    },
    {
      id: "3",
      title: "The Divine Liturgy",
      description: "Understanding the structure and meaning of Orthodox worship",
      date: "2024-12-15",
      duration: "60 min",
      students: 0,
      status: "draft",
    },
  ])

  const [newLesson, setNewLesson] = useState({
    title: "",
    description: "",
    date: "",
    duration: "",
  })

  const handleCreateLesson = () => {
    const lesson: Lesson = {
      id: Date.now().toString(),
      ...newLesson,
      students: 0,
      status: "draft",
    }
    setLessons((prev) => [...prev, lesson])
    setNewLesson({ title: "", description: "", date: "", duration: "" })
  }

  const getStatusColor = (status: Lesson["status"]) => {
    switch (status) {
      case "upcoming":
        return "default"
      case "completed":
        return "secondary"
      case "draft":
        return "outline"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Lesson Management</h2>
          <p className="text-muted-foreground">Create and manage your Sunday school lessons</p>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Lesson
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Lesson</DialogTitle>
              <DialogDescription>Add a new lesson to your curriculum</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Lesson Title</Label>
                <Input
                  id="title"
                  value={newLesson.title}
                  onChange={(e) => setNewLesson((prev) => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter lesson title"
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newLesson.description}
                  onChange={(e) => setNewLesson((prev) => ({ ...prev, description: e.target.value }))}
                  placeholder="Describe the lesson content"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={newLesson.date}
                    onChange={(e) => setNewLesson((prev) => ({ ...prev, date: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="duration">Duration</Label>
                  <Input
                    id="duration"
                    value={newLesson.duration}
                    onChange={(e) => setNewLesson((prev) => ({ ...prev, duration: e.target.value }))}
                    placeholder="e.g., 45 min"
                  />
                </div>
              </div>
              <Button onClick={handleCreateLesson} className="w-full">
                Create Lesson
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {lessons.map((lesson) => (
          <Card key={lesson.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <CardTitle className="text-lg">{lesson.title}</CardTitle>
                <Badge variant={getStatusColor(lesson.status)}>{lesson.status}</Badge>
              </div>
              <CardDescription>{lesson.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>{new Date(lesson.date).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  <span>{lesson.duration}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{lesson.students} students</span>
                </div>
              </div>
              <div className="mt-4 flex space-x-2">
                <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                  Edit
                </Button>
                <Button size="sm" className="flex-1">
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
