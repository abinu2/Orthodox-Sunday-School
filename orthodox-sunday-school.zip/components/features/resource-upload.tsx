"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Upload, FileText, ImageIcon, Music, Video, Download, Trash2 } from "lucide-react"

interface Resource {
  id: string
  name: string
  type: "pdf" | "image" | "audio" | "video"
  category: string
  uploadDate: string
  size: string
}

export function ResourceUpload() {
  const [resources, setResources] = useState<Resource[]>([
    {
      id: "1",
      name: "Nativity Fast Guide.pdf",
      type: "pdf",
      category: "Lesson Plans",
      uploadDate: "2024-12-01",
      size: "2.3 MB",
    },
    {
      id: "2",
      name: "Orthodox Icons Collection.zip",
      type: "image",
      category: "Visual Resources",
      uploadDate: "2024-11-28",
      size: "15.7 MB",
    },
    {
      id: "3",
      name: "Liturgical Chants.mp3",
      type: "audio",
      category: "Audio Resources",
      uploadDate: "2024-11-25",
      size: "8.4 MB",
    },
  ])

  const getFileIcon = (type: Resource["type"]) => {
    switch (type) {
      case "pdf":
        return FileText
      case "image":
        return ImageIcon
      case "audio":
        return Music
      case "video":
        return Video
      default:
        return FileText
    }
  }

  const getTypeColor = (type: Resource["type"]) => {
    switch (type) {
      case "pdf":
        return "default"
      case "image":
        return "secondary"
      case "audio":
        return "outline"
      case "video":
        return "destructive"
      default:
        return "default"
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload Resources</CardTitle>
          <CardDescription>Add lesson materials, prayers, chants, and other educational content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="file">Select File</Label>
              <Input id="file" type="file" multiple />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="lesson-plans">Lesson Plans</SelectItem>
                  <SelectItem value="prayers">Prayers</SelectItem>
                  <SelectItem value="chants">Chant Guides</SelectItem>
                  <SelectItem value="icons">Icon Packs</SelectItem>
                  <SelectItem value="videos">Educational Videos</SelectItem>
                  <SelectItem value="worksheets">Worksheets</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button className="w-full">
            <Upload className="mr-2 h-4 w-4" />
            Upload Files
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>My Resources</CardTitle>
          <CardDescription>Manage your uploaded teaching materials</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {resources.map((resource) => {
              const IconComponent = getFileIcon(resource.type)
              return (
                <div key={resource.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <IconComponent className="h-8 w-8 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{resource.name}</p>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <span>{resource.category}</span>
                        <span>•</span>
                        <span>{resource.size}</span>
                        <span>•</span>
                        <span>{new Date(resource.uploadDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Badge variant={getTypeColor(resource.type)}>{resource.type.toUpperCase()}</Badge>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
